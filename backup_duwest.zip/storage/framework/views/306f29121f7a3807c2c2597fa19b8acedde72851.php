

<?php $__env->startSection('template_title'); ?>
    <?php echo e($venta->name ?? 'Show Venta'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="card card-default">
                    <div class="card-header">
                        <span class="card-title">Descripcion detallada venta
                        <a style="float:right;" class="btn btn-primary" href="<?php echo e(route('ventas.index')); ?>"> Back</a>
                        </span>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                        <div class="input-group input-group-lg">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-lg"><button type="button" class="btn btn-lg">descripcion de venta</button></span>
                            </div>
                                <?php $__currentLoopData = $ventacreada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ventacrea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input  value="<?php echo e($ventacrea->desc); ?>" disabled  type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <li class="list-group-item">
                            
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Producto</span>
                                </div>

                                <?php $__currentLoopData = $prodused; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input disabled value="<?php echo e($prod->desc_prod_use); ?>" id="first" type="text" class="form-control" aria-label="Large" aria-describedby="inputGroup-sizing-sm">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="input-group-append">
                                    <span class="input-group-text"> <input type="hidden" id="partotal" value="<?php echo e($sumparticipacion); ?>"> Participacion total: <?php echo e($sumparticipacion); ?>%</span>
                                </div>
                            </div>

                            </li>
                                <li class="list-group-item"><div class="card" >
                               
                                <ul class="list-group list-group-flush">
                                
                                <?php $__currentLoopData = $culused; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item">


                                <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <button class="btn btn-outline-primary" type="button">Cultivo</button>
                                </div>
                                <input disabled value="<?php echo e($cult->desc_cult_use); ?>" type="text" class="form-control" placeholder="" aria-label="" aria-describedby="basic-addon1">
                                </div>

                                <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <button class="btn btn-outline-secondary" type="button">Participación</button>
                                </div>
                                <input disabled value="<?php echo e($cult->participacion); ?>%" type="text" class="form-control" placeholder="" aria-label="" aria-describedby="basic-addon1">
                                </div>

                                <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <button class="btn btn-outline-secondary" type="button">Dosis por hectarea en litros</button>
                                </div>
                                <input disabled value="<?php echo e($cult->litros); ?>" type="text" class="form-control" placeholder="" aria-label="" aria-describedby="basic-addon1">
                                </div>

                                <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <button class="btn btn-outline-secondary" type="button">Número de aplicaciones al año</button>
                                </div>
                                <input disabled value="<?php echo e($cult->aplicaciones); ?>" type="text" class="form-control" placeholder="" aria-label="" aria-describedby="basic-addon1">
                                </div>

                                <div class="card" >
                                    <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $bbused; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bbuse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cult->id_cult_use == $bbuse->blancobiologico_cultivo_id): ?>
                                        <li class="list-group-item">
                                        <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <button class="btn btn-outline-success" type="button"> Blanco biológico </button>
                                        </div>
                                        <input disabled value="<?php echo e($bbuse->desc_bb_use); ?>" type="text" class="form-control" placeholder="" aria-label="" aria-describedby="basic-addon1">
                                        </div>
                                        </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>

                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                                </ul>
                                </div>
                    </ul>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\duwest\resources\views/venta/show.blade.php ENDPATH**/ ?>