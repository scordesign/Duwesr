

<?php $__env->startSection('template_title'); ?>
    Venta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                        

                            <span id="card_title">
                                <h3>Venta</h3>     
                            
                                <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Buscar</span>
                                </div>
                                <input id="buscar" onkeyup="buscar()" type="search" class="form-control" placeholder="buscar" aria-label="Username" aria-describedby="basic-addon1">
                                </div>
                            </span>
                            
                            
                             <div class="float-right">
                                <a href="
                                <?php
                                use App\Http\Controllers\VentaController as ventacontroler;
                                echo action([ventacontroler::class, 'create'] , ['idventa' => 0]); 
                                ?>"
                                class="btn btn-primary btn-sm float-right"  data-placement="left">
                                 Crear Nuevo</a>
                              </div>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <input type="hidden" id="count" value="<?php echo e($ventas->count()); ?>">
                    <script>
                        function buscar() {
                            var buscar =document.getElementById("buscar").value.toLowerCase();
                            var count = Number(document.getElementById("count").value);
                            var acu = 1 ;
                            while (acu <= count) {
                                var elements = document.getElementById(acu).innerHTML.toLowerCase();
                                var element = document.getElementById(acu);
                                if (elements.includes(buscar)) {
                                    element.classList.remove("vis");
                                } else {
                                    element.classList.add("vis");
                                }
                                acu++;
                            }
                        }
                    </script>
                    <style>
                        .vis{
                            display: none;
                        }
                    </style>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										
										<th>Descripción venta</th>
										
										<th>Vendedor</th>

                                        <th>acciones 
                                            
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="<?php echo e(++$i); ?>">
                                            <td><p > <?php echo e($i); ?> </p></td>
                                            
										
											<td><?php echo e($venta->desc); ?></td>
											
											<td><?php echo e($venta->name); ?></td>
                                            <td>
                                            <?php if($venta->estado == 0): ?>
                                            <form action="<?php echo e(route('ventas.destroy',$venta->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('ventas.show',$venta->id)); ?>"><i class="fa fa-fw fa-eye"></i> Mostrar</a>
                                                    <a class="btn btn-sm btn-success" href="
                                                    <?php
                                                    echo action([ventacontroler::class, 'create'] , ['idventa' => $venta->id]); 
                                                    ?>"
                                                    ><i class="fa fa-fw fa-edit"></i> Editar</a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> Eliminar</button>
                                            </form>
                                            <?php else: ?>
                                            <a class="btn btn-sm btn-primary " href="<?php echo e(route('ventas.show',$venta->id)); ?>"><i class="fa fa-fw fa-eye"></i> Mostrar</a>

                                            <?php endif; ?>
  
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $ventas->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/venta/index.blade.php ENDPATH**/ ?>