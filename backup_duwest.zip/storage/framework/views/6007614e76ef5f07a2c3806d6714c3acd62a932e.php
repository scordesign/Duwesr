<table>
    <thead>
      
    </thead>
    <tbody>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
       <td><b>Nombre</b></td>
       <td><b>Correo Electronico</b></td>
      </tr>

    <tr>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->email); ?></td>
</tr>
<tr>
        <td><b>Productos</b></td>
        <td><b>Producto asignado</b></td>
</tr>
  <?php $__currentLoopData = $productosxusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php if($user->id == $productos->id_usu): ?>
    
    <tr>
        <td></td>
        <td><?php echo e($productos->nombre); ?></td>
</tr>
 <?php endif; ?>  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
        <td><b>Municipios</b></td>
        <td><b>Municipio asignado</b></td>
</tr>
<?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php if($user->id == $muni->id_usu): ?>
    
    <tr>
        <td></td>
        <td><?php echo e($muni->desc); ?></td>
</tr>
 <?php endif; ?>  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/exports/users.blade.php ENDPATH**/ ?>