<div class="box box-info padding-1">
<?php $__currentLoopData = $tietocreadarecien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tieto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    

<div class="box-body">  
    <div class="input-group input-group-lg">
    <div class="input-group-prepend">
        <span class="input-group-text" id="inputGroup-sizing-lg"> <button type="button" class="btn  btn-lg">Descripción nuevo tieto</button> </span>
    </div>
    <input disabled value="<?php echo e($tieto->desc); ?>" type="text" class="form-control" aria-label="Large" aria-describedby="inputGroup-sizing-sm">
    </div>

    <br>
    <style>
        .vis{
            display: none;
        }
    </style>
<?php if($cultivostietos->count() == 0): ?>
    <form action="<?php echo e(route('Cultivostietos.store')); ?>"  method="POST">

    <div class="input-group mb-3">
    <div class="input-group-prepend">
        <label class="input-group-text" for="inputGroupSelect01">Cultivo</label>
    </div>
        <?php echo csrf_field(); ?>
        <select name="cultmother_cult_ti_id" class="form-select">
        <?php $__currentLoopData = $cultivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cult->id); ?>"><?php echo e($cult->cultivo); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="number" name="hectareas" class="form-control" placeholder="Hectareas">
        <input type="hidden" name="tieto_cult_ti_id" value="<?php echo e($tieto->id); ?>">
        <div class="input-group-append">
        <button class="btn btn-outline-success" type="submit">agregar</button>


    </div>
    </div>
    </form>
<?php endif; ?>
    <?php $__currentLoopData = $cultivostietos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cultti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>

            function blanbio(cond) {
                var blancobio = document.getElementById("blanbio"+cond);
                if (blancobio.classList.contains("vis")) {
                    blancobio.classList.remove("vis");
                } else {
                    blancobio.classList.add("vis");
                }
            if (document.getElementById("condicional"+cond) == null) {
                console.log('hola');
                var opcio = document.getElementById("condicional"+cond);
                opcio.classList.add("vis");
            } else {
                console.log('chao');
                var opcio = document.getElementById("condicional0"+cond);
                opcio.classList.add("vis");
            }
            }

            </script>

    
    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <label class="input-group-text" for="inputGroupSelect01">Cultivo creado</label>
        </div>
        <input disabled value="<?php echo e($cultti->desc_cult_ti); ?>" type="text" class="form-control" aria-label="Large" aria-describedby="inputGroup-sizing-sm">
        <input disabled value="<?php echo e($cultti->hectareas); ?> Hectareas" type="text" class="form-control" aria-label="Large" aria-describedby="inputGroup-sizing-sm">
        
        <form action="<?php echo e(route('Cultivostietos.destroy',$cultti->id_cult_ti)); ?>" method="POST" >
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <input type="hidden" name="idtieto" value="<?php echo e($tieto->id); ?>">
    <button class="btn btn-outline-danger" type="submit">Eliminar</button>
    </form>

        
            <button onclick="blanbio(<?php echo e($cultti->id_cult_ti); ?>)" class="btn btn-outline-secondary" type="submit">Crear formulacion ▼</button>
    </div>
    <div class="vis" id="blanbio<?php echo e($cultti->id_cult_ti); ?>">
    <script>
function replace(cond) {
    var opciones = document.getElementById("opciones"+cond).value;
    var opcion0 = document.getElementById("opcion0"+cond);
    var opcion1 = document.getElementById("opcion1"+cond);
    if (Number(opciones) == 0) {
            opcion1.classList.add("vis");
        opcion0.classList.remove("vis");
    } else {

            opcion0.classList.add("vis");
        opcion1.classList.remove("vis");
    }
    
}
        </script>

    
    <?php $__currentLoopData = $blancosbiologicostietos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blacobiotieto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($blacobiotieto->cultivo_bb_ti_id == $cultti->id_cult_ti): ?>
   <div id="condicional<?php echo e($cultti->id_cult_ti); ?>">     
        <div class="input-group mb-3">
            <div class="input-group-prepend">
            </div>
            <input value="Incidencia sobre el area cultivada: <?php echo e($blacobiotieto->incidencia); ?>" type="text" disabled class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
            <input value="Temporadas de mayor aplicación: <?php echo e($blacobiotieto->temp_aplica); ?>" type="text" disabled class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
        </div>

        <div class="input-group mb-3">
            <div class="input-group-prepend">
            </div>
            <input value="Número de aplicaciones al año en promedio: <?php echo e($blacobiotieto->num_apli); ?>" type="text" disabled class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
            <input value="Nombre Blanco Biologico: <?php echo e($blacobiotieto->blancobiologico); ?>" type="text" disabled class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
        </div>
        <?php $__currentLoopData = $ingredientesactivosusados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingactivous): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($blacobiotieto->id_bb_ti == $ingactivous->bb_ing_act_id): ?>
        <div class="input-group mb-3">
        <input type="text" class="form-control" disabled value="<?php echo e($ingactivous->desc_ing_act_use); ?>" aria-describedby="basic-addon2">
        <input type="text" class="form-control" disabled value="Dosis por hectarea: <?php echo e($ingactivous->dosis); ?>" aria-describedby="basic-addon2">
        <input type="text" class="form-control" disabled value="Participación del mercado: <?php echo e($ingactivous->porcentaje); ?>%" aria-describedby="basic-addon2">
        <input type="text" class="form-control" disabled value="Precio KG/LT: $<?php echo e($ingactivous->precio); ?>" aria-describedby="basic-addon2">
        <input type="text" class="form-control" disabled value="Marca comercial: <?php echo e($ingactivous->marcacomercial); ?>" aria-describedby="basic-addon2">
        <div class="input-group-append">
        <form action="<?php echo e(route('Ingredientesactivosuseds.destroy',$ingactivous->id_ing_act_use)); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="hidden" name="idtieto" value="<?php echo e($tieto->id); ?>">
            <button class="btn btn-outline-danger" type="submit">Eliminar</button>
        </form>
        </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <form action="<?php echo e(route('Ingredientesactivosuseds.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
            <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Ingrediente activo</span>
            </div>
            <select class="form-select" name="ingmother_ing_act_id" id="">
            <?php $__currentLoopData = $Ingredientesactivo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingactivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ingactivo->id); ?>"><?php echo e($ingactivo->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>


            <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text">Participación del mercado</span>
            </div>
            <input name="porcentaje" max="100" type="number" class="form-control" aria-label="Amount (to the nearest dollar)">
            <div class="input-group-append">
                <span class="input-group-text">%</span>
            </div>
            </div>

            <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Dosis por hectarea</span>
            </div>
            <input name="dosis" type="number" class="form-control"  aria-label="Username" aria-describedby="basic-addon1">
            </div>
            
            <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Precio KG/LT</span>
            </div>
            <input name="precio" type="number" class="form-control"  aria-label="Username" aria-describedby="basic-addon1">
            </div>

            <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Marca comercial</span>
            </div>
            <input name="marcacomercial" type="text" class="form-control"  aria-label="Username" aria-describedby="basic-addon1">
            </div>
            
            

            <input type="hidden" name="tieto_ing_act_use" value="<?php echo e($tieto->id); ?>">
            <input type="hidden" name="cult_ing_act_id" value="<?php echo e($cultti->id_cult_ti); ?>">
            <input type="hidden" name="bb_ing_act_id" value="<?php echo e($blacobiotieto->id_bb_ti); ?>">
            
            <input type="submit" style="width:100%;" class="btn btn-outline-primary btn-block" value="agregar ingredienta activo"><br>


    </form>

    </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    <form action="<?php echo e(route('Blancosbiologicostietos.store')); ?>" id="condicional0<?php echo e($cultti->id_cult_ti); ?>"  method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tieto_bb_ti_id" value="<?php echo e($tieto->id); ?>">
            <input type="hidden" name="cultivo_bb_ti_id" value="<?php echo e($cultti->id_cult_ti); ?>">
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Seleccione Blanco biologico</label>
                </div>
                <select  class="form-select" name="bbmother_bb_ti_id" >
                <?php $__currentLoopData = $blancosbiologicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blacobiol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($blacobiol->id); ?>"><?php echo e($blacobiol->blancobiologico); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Temporadas de mayor aplicación</label>
                </div>
                <select onchange="replace(<?php echo e($cultti->id_cult_ti); ?>)" name="temp_aplica" class="form-select"  id="opciones<?php echo e($cultti->id_cult_ti); ?>">
                    <option selected disabled>seleccione</option>
                    <option value="0">Climatico</option>
                    <option value="1">Mensual</option>
                </select>
            </div>

            <div class="vis input-group mb-3" id="opcion0<?php echo e($cultti->id_cult_ti); ?>">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Seleccione clima</label>
                </div>
                <select class="form-select" name="clima" >
                <option selected>Seleccione</option>
                    <option value="Lluvioso">Lluvioso</option>
                    <option value="Calido">Calido</option>
                </select>
            </div>

                
                

            <div class="vis input-group mb-3" id="opcion1<?php echo e($cultti->id_cult_ti); ?>">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">Seleccione meses <br> 
                    (para seleccionar varios meses <br> presione control mas click)</span>
                </div>
                <select class="form-select" multiple name="meses[]" aria-label="multiple select example">
                <option selected >Seleccione</option>
                <option value="Enero">Enero</option>
                <option value="Febrero">Febrero</option>
                <option value="Marzo">Marzo</option>
                <option value="Abril">Abril</option>
                <option value="Mayo">Mayo</option>
                <option value="Junio">Junio</option>
                <option value="Julio">Julio</option>
                <option value="Agosto">Agosto</option>
                <option value="Septiembre">Septiembre</option>
                <option value="Octubre">Octubre</option>
                <option value="Noviembre">Noviembre</option>
                <option value="Diciembre">Diciembre</option>
                </select>        
            </div>

            <div class="input-group mb-3">
                <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1">Número de aplicaciones al año
                        en promedio</span>
                </div>
                    <input type="text" name="num_apli" class="form-control"  aria-label="Username" aria-describedby="basic-addon1">
            </div>

            <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Incidencia sobre el area cultivada</span>
            </div>
            <input name="Incidencia" type="number" step="0.01" class="form-control"  aria-label="Username" aria-describedby="basic-addon1">
            </div>

            <input type="submit" style="width:100%;" class="btn btn-outline-primary btn-block" value="agregar Blanco Biologico">

    </form>
    </div><br>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div> 
</div>
<div style="display:flex;">
<!-- <form action="<?php echo e(route('tietos.store')); ?>" method="POST" style="width:33.333333333333333333333333333333%;">
    <?php echo csrf_field(); ?>
    
    <input type="hidden" name="idtieto" value="<?php echo e($tieto->id); ?>">   
    <input type="hidden" name="estado" value="1">   
    <input type="submit" style="width:100%;" class="btn btn-outline-success btn-lg btn-block" value="terminar">
    </form> -->
    <form action="<?php echo e(route('tietos.store')); ?>"  method="POST" style="width:50%;">
    <?php echo csrf_field(); ?>
    
    <input type="hidden" name="idtieto" value="<?php echo e($tieto->id); ?>">   
    <input type="hidden" name="estado" value="1">     
    <input type="hidden" name="nombre" value="<?php $__currentLoopData = $cultivostietos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cultus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($cultus->desc_cult_ti); ?> <?php $__currentLoopData = $blancosbiologicostietos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blacobiotieto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> (<?php echo e($blacobiotieto->blancobiologico); ?>)
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ">     
    <input type="submit" style="width:100%;" class="btn btn-outline-primary btn-lg btn-block" value="guardar cambios">
    </form>

    <form action="<?php echo e(route('tietos.destroy',$tieto->id)); ?>" method="POST" style="width:50%;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
        <input type="submit" style="width:100%;" class="btn btn-outline-danger btn-lg btn-block" value="cancelar">
    </form>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\duwest\resources\views/tieto/form.blade.php ENDPATH**/ ?>