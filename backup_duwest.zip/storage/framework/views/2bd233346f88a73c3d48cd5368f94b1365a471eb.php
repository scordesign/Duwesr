<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('blanco biologico')); ?>

            <?php echo e(Form::text('blancobiologico', $blancosbiologico->blancobiologico, ['class' => 'form-control' . ($errors->has('blancobiologico') ? ' is-invalid' : ''), 'placeholder' => 'Blancobiologico'])); ?>

            <?php echo $errors->first('blancobiologico', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Enviar</button>
    </div>
</div><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/blancosbiologico/form.blade.php ENDPATH**/ ?>