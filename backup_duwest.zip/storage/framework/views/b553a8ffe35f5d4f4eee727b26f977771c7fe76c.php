<table>
    <thead>
       

    </thead>
    <tbody>

    <?php $__currentLoopData = $Venta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ventas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><b>Usuario</b></td>
       <td><b>Venta</b></td>
      </tr>
    <tr>
        <td><?php echo e($ventas->name); ?></td>
        <td><?php echo e($ventas->desc); ?></td>
    </tr>
    <tr>
        <td></td>
        <td><b>Nombre del producto</b></td>
        </tr>
    <tr>
        <td></td>
        <td><?php echo e($ventas->desc_prod_use); ?></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td><b>Nombre cultivo usado</b></td>
        <td><b>Participación</b></td>
        <td><b>Dosis por hectarea en litros</b></td>
        <td><b>Número de aplicaciones al año</b></td>
        
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td><?php echo e($ventas->desc_cult_use); ?></td>
        <td><?php echo e($ventas->participacion); ?></td>
        <td><?php echo e($ventas->litros); ?></td>
        <td><?php echo e($ventas->aplicaciones); ?></td>
        
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td><b>Nombre del blanco biologico</b></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td><?php echo e($ventas->desc_bb_use); ?></td>
        
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/exports/venta.blade.php ENDPATH**/ ?>