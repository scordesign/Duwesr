<table>
    <thead>

    </thead>
    <tbody>

    <?php $__currentLoopData = $tieto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tietos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
       <td><b>usuario</b></td>
       <td><b>Tieto</b></td>
      </tr>
    <tr>
        <td><?php echo e($tietos->name); ?></td>
        <td><?php echo e($tietos->desc); ?></td>
    </tr>
    <tr>
        <td></td>
        <td><b>Nombre Cultivo</b></td>
        <td><b>Hectareas</b></td>
    </tr>
    <tr>
        <td></td>
        <td><?php echo e($tietos->desc_cult_ti); ?></td>
        <td><?php echo e($tietos->hectareas); ?> Hectareas</td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td><b>Nombre Blanco Biologico</b></td>
        <td><b>Incidencia sobre el area cultivada</b></td>
        <td><b>Temporadas de mayor aplicacion</b></td>
        <td><b>Numero de aplicaciones al año en promedio</b></td>
        
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td><?php echo e($tietos->desc_bb_ti); ?></td>
        <td><?php echo e($tietos->incidencia); ?></td>
        <td><?php echo e($tietos->temp_aplica); ?></td>
        <td><?php echo e($tietos->num_apli); ?></td>
        
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td><b>Nombre ingrediente activo</b></td>
        <td><b>Participacion del mercado</b></td>
        <td><b>Dosis por hectarea</b></td>
        <td><b>Precio KG/LT</b></td>
        <td><b>Marce comercial</b></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td><?php echo e($tietos->desc_ing_act_use); ?></td>
        <td><?php echo e($tietos->porcentaje); ?></td>
        <td><?php echo e($tietos->dosis); ?></td>
        <td><?php echo e($tietos->precio); ?></td>
        <td><?php echo e($tietos->marcacomercial); ?></td>
        
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/exports/tieto.blade.php ENDPATH**/ ?>