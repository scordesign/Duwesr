



<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row justify-content-center">

        <div class="col-md-8">

            <div class="card">

                <div class="card-header"><?php echo e(__('Dashboard - Duwest')); ?></div>



                <div class="card-body">

                    <?php if(session('status')): ?>

                        <div class="alert alert-success" role="alert">

                            <?php echo e(session('status')); ?>


                        </div>

                        



                        </div>

                    <?php endif; ?>



                 

                    <div class="row justify-content-center">
                    <?php if(Auth::user()->estatus==1): ?>
                            <div class="ventas"> 

                                <h1>Ventas por Cultivo</h1>

                                <a href="<?php echo e(route('ventas.index')); ?>"> <img src="img/vineyard-g1dfbc123a_1280.jpeg"></a>



                            </div>

                            <div class="tieto"> 

                                <h1>Tieto</h1>

                                <a href="<?php echo e(route('tietos.index')); ?>"> <img src="img/man-g3c3280a03_1280.jpeg"></a>

                            </div>

                            </div>
                    <?php else: ?>
                    <h2> Su usuario ha sido desactivado si cree que esto es un error contactese con el administrador ,click en el siguiente boton para salir</h2>
                    

                                    <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>"

                                       onclick="event.preventDefault();

                                                     document.getElementById('logout-form').submit();">

                                        <?php echo e(__('Salir')); ?>


                                    </a>


                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">

                                        <?php echo csrf_field(); ?>

                                    </form>

                
                    <?php endif; ?>
                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\duwest\resources\views/home.blade.php ENDPATH**/ ?>