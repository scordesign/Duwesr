<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('desc')); ?>

            <?php echo e(Form::text('desc', $municipio->desc, ['class' => 'form-control' . ($errors->has('desc') ? ' is-invalid' : ''), 'placeholder' => 'Desc'])); ?>

            <?php echo $errors->first('desc', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('id_usu')); ?>

            <?php echo e(Form::text('id_usu', $municipio->id_usu, ['class' => 'form-control' . ($errors->has('id_usu') ? ' is-invalid' : ''), 'placeholder' => 'Id Usu'])); ?>

            <?php echo $errors->first('id_usu', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\duwest\resources\views/municipio/form.blade.php ENDPATH**/ ?>