<div class="box box-info padding-1">
    <div class="box-body">
    <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Asignador de precio</span>
            </div>
            <input type="text" disabled  value="Nombre" class="form-control"  >
            <input type="text" disabled  value="Marca comercial" class="form-control"  >
            <input type="tect" disabled  value="Precio" class="form-control"  >
            </div>
        <form action="<?php echo e(route('precios_ings.update', $idtieto)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PATCH')); ?>

            <?php 
            $i = 1;
            ?>
    <?php $__currentLoopData = $PreciosIngnombre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preciosIng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Asignar precios</span>
            </div>
            <input type="text" disabled name="nombre<?php echo e($i); ?>" value="<?php echo e($preciosIng->desc_pre_ing); ?>" class="form-control"  >
            <input type="text"  name="marcacomercial<?php echo e($i); ?>" value="<?php echo e($preciosIng->marca_comercial); ?>" class="form-control"  >
            <input type="number"  name="precio<?php echo e($i); ?>" value="<?php echo e($preciosIng->Precio); ?>" class="form-control"  >
            <input type="hidden"  name="id_ing<?php echo e($i++); ?>" value="<?php echo e($preciosIng->id_pre_ing); ?>" class="form-control"  >

        </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" name="count" value="<?php echo e($PreciosIngnombre->count()); ?>">
    
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Asignar precios</button>
    </div>
    </form>
</div><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/preciosing/form.blade.php ENDPATH**/ ?>