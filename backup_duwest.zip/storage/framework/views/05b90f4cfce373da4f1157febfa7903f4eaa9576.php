<table>
    <thead>
       <tr>
       <th><b>Usuario</b></th>
       <th><b>Marca comercial</b></th>
       <th><b>Precio</b></th>
       <th><b>Nombre de ingrediente activos</b></th>
      </tr>

    </thead>
    <tbody>

    <?php $__currentLoopData = $precio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td><?php echo e($pre->name); ?></td>
        <td><?php echo e($pre->marca_comercial); ?></td>
        <td>$<?php echo e($pre->Precio); ?></td>
        <td><?php echo e($pre->desc_pre_ing); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/exports/ingredientes.blade.php ENDPATH**/ ?>