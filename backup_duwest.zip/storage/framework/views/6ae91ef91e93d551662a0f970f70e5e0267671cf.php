<?php $__env->startSection('template_title'); ?>
    <?php echo e($tieto->name ?? 'Show Tieto'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Mostrar Tieto</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('tietos.index')); ?>"> Volver</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Desc:</strong>
                            <?php echo e($tieto->desc); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e($tieto->estado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Id Usu:</strong>
                            <?php echo e($tieto->id_usu); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/tieto/show.blade.php ENDPATH**/ ?>