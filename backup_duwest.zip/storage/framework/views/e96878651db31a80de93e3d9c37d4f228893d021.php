<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            
            <?php echo e(Form::hidden('id_ing_act_use', $ingredientesactivosused->id_ing_act_use, ['class' => 'form-control' . ($errors->has('id_ing_act_use') ? ' is-invalid' : ''), 'placeholder' => 'Id Ing Act Use'])); ?>

            <?php echo $errors->first('id_ing_act_use', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('porcentaje')); ?>

            <?php echo e(Form::text('porcentaje', $ingredientesactivosused->porcentaje, ['class' => 'form-control' . ($errors->has('porcentaje') ? ' is-invalid' : ''), 'placeholder' => 'Porcentaje'])); ?>

            <?php echo $errors->first('porcentaje', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            
            <?php echo e(Form::hidden('desc_ing_act_use', $ingredientesactivosused->desc_ing_act_use, ['class' => 'form-control' . ($errors->has('desc_ing_act_use') ? ' is-invalid' : ''), 'placeholder' => 'Desc Ing Act Use'])); ?>

            <?php echo $errors->first('desc_ing_act_use', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('dosis')); ?>

            <?php echo e(Form::text('dosis', $ingredientesactivosused->dosis, ['class' => 'form-control' . ($errors->has('dosis') ? ' is-invalid' : ''), 'placeholder' => 'Dosis'])); ?>

            <?php echo $errors->first('dosis', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            
            <?php echo e(Form::hidden('tieto_ing_act_use', $ingredientesactivosused->tieto_ing_act_use, ['class' => 'form-control' . ($errors->has('tieto_ing_act_use') ? ' is-invalid' : ''), 'placeholder' => 'Tieto Ing Act Use'])); ?>

            <?php echo $errors->first('tieto_ing_act_use', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            
            <?php echo e(Form::hidden('ingmother_ing_act_id', $ingredientesactivosused->ingmother_ing_act_id, ['class' => 'form-control' . ($errors->has('ingmother_ing_act_id') ? ' is-invalid' : ''), 'placeholder' => 'Ingmother Ing Act Id'])); ?>

            <?php echo $errors->first('ingmother_ing_act_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">

            <?php echo e(Form::hidden('cult_ing_act_id', $ingredientesactivosused->cult_ing_act_id, ['class' => 'form-control' . ($errors->has('cult_ing_act_id') ? ' is-invalid' : ''), 'placeholder' => 'Cult Ing Act Id'])); ?>

            <?php echo $errors->first('cult_ing_act_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">

            <?php echo e(Form::hidden('bb_ing_act_id', $ingredientesactivosused->bb_ing_act_id, ['class' => 'form-control' . ($errors->has('bb_ing_act_id') ? ' is-invalid' : ''), 'placeholder' => 'Bb Ing Act Id'])); ?>

            <?php echo $errors->first('bb_ing_act_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <input type="hidden" name="idtieto" value="<?php echo e($idtieto); ?>">
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">enviar</button>
    </div>
</div><?php /**PATH /home/duwestcolombia/duclient.duwestcolombia.com/resources/views/ingredientesactivosused/form.blade.php ENDPATH**/ ?>