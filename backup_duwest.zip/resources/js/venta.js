function add() {
    var elementlist = document.getElementsByClassName("table");
    var add = document.getElementsByTagName("tr");
    console.log(elementlist.length);
    
}