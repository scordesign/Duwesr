
<div class="add" id="add" onclick="add()" style="    width: 100%;
    background: black;"> <img src="http://127.0.0.1:8000/css/images/mas.png" alt=""> 
    </div>

